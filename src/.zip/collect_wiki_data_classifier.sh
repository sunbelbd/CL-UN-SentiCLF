for lg in th tr ur vi zh; do
  bash get-data-wiki.sh $lg
done
# ar bg de el en es fr hi ru sw 
