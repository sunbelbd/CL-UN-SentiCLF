# set epoch_size=50000, tokens_per_batch=-1 and clf_layers=0, lr=0.001 when finetuning on CLF only 
# or CLF with enc-dec tuning.
# set epoch_size=200000, tokens_per_batch=640 and clf_layers=3 when running on all datasets.
# --optimizer adam_inverse_sqrt,beta1=0.9,beta2=0.98,lr=0.0001 \
#export NGPU=2
# python -u -m torch.distributed.launch --nproc_per_node=$NGPU train.py \
# --reload_model './pretrain/pretrain_enfr/mlm_enfr_mt_dis_1024_20191011.pth,./pretrain/pretrain_enfr/mlm_enfr_mt_dis_1024_20191011.pth,./pretrain/pretrain_enfr/mlm_enfr_mt_dis_1024_20191011.pth' \
#
# Read arguments
#

POSITIONAL=()
while [[ $# -gt 0 ]]
do
key="$1"
case $key in
  --gpuid)
    GID="$2"; shift 2;;
  --exp_name)
    EXPNAME="$2"; shift 2;;
  --clf_attn)
    CLF_ATTN="$2"; shift 2;;
  --clf_mtv)
    CLF_MTV="$2"; shift 2;;
  --data_category)
    DATA="$2"; shift 2;;
  *)
  POSITIONAL+=("$1")
  shift
  ;;
esac
done
set -- "${POSITIONAL[@]}"

export CUDA_VISIBLE_DEVICES=$GID
python -u train.py \
--exp_name $EXPNAME \
--dump_path ./dumped/ \
--reload_model './pretrain/pretrain_enfr/mlm_enfr_1024.pth,./pretrain/pretrain_enfr/mlm_enfr_1024.pth' \
--data_path ./data/processed/en-fr/ \
--lgs 'en-fr' \
--ae_steps 'en,fr' \
--bt_steps 'en-fr-en,fr-en-fr' \
--dis_steps 0 \
--max_len 100 \
--word_shuffle 3 \
--word_dropout 0.1 \
--data_category books \
--lambda_dis 0 \
--lambda_clf 8 \
--lambda_div 0.1 \
--clf_mtv  $CLF_MTV \
--clf_steps 1 \
--clf_batch_norm True \
--clf_attention $CLF_ATTN \
--clf_dropout 0.3 \
--clf_layers 2 \
--word_blank 0.1 \
--lambda_ae '0:1,100000:0.1,300000:0' \
--encoder_only False \
--emb_dim 1024 \
--n_layers 6 \
--n_heads 8 \
--optimizer adam,lr=0.00001 \
--dropout 0.1 \
--attention_dropout 0.1 \
--gelu_activation true \
--tokens_per_batch -1 \
--batch_size 40 \
--bptt 256 \
--max_epoch 100000 \
--epoch_size 20000 \
--eval_bleu true \
--stopping_criterion 'valid_en_clf_acc,5' \
--validation_metrics 'valid_en_clf_acc'