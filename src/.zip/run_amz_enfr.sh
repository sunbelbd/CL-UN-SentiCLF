# unsupMTDiscCLF_enfr finetuneEncDecCLFAttn_enfr
# we backproporgate clf loss no matter what language is being trained. Remember lang1 == 'en' condition
# nohup bash runUnsuperMTDisCLF.sh --gpuid 1 --exp_name unsupMTDiscCLF_enfr --data_category music --train_dis True --train_encdec True --train_bt True --clf_atten True --clf_mtv True >unmt_dis_clf_fbinit_full_20191016_amzmusic.log 2>& 1 &

# nohup bash runUnsuperMTDisCLF.sh --gpuid 2 --exp_name unsupMTDiscCLF_enfr --data_category music --train_dis True --train_encdec True --train_bt False --clf_atten True --clf_mtv True >unmt_dis_clf_fbinit_wobt_20191016_amzmusic.log 2>& 1 &

nohup bash runUnsuperMTDisCLF.sh --gpuid 4 --exp_name finetuneEncDecCLFAttn_enfr --data_category music --train_dis False --train_encdec False --train_bt False --clf_atten True --clf_mtv False >fine_tune_encdec_clf_attn_fbinit_womtv_20191016_amzmusic.log 2>& 1 &

# nohup bash runUnsuperMTDisCLF.sh --gpuid 6 --exp_name finetuneEncDecCLFAttn_enfr --data_category music --train_dis False --train_encdec False --train_bt False --clf_atten True --clf_mtv True >fine_tune_encdec_clf_fbinit_20191016_amzmusic.log 2>& 1 &